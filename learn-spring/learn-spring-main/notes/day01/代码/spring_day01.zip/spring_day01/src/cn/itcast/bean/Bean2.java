package cn.itcast.bean;

public class Bean2 {

	public void add() {
		System.out.println("bean2.........");
	}
}
