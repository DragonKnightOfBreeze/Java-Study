package cn.itcast.bean;

public class Bean2Factory {

	//静态的方法，返回Bean2对象
	public static Bean2 getBean2() {
		return new Bean2();
	}
}
