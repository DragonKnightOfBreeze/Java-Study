package cn.itcast.ioc;

public class UserDao {

	public void add() {
		System.out.println("dao.........");
	}
}
