package cn.itcast.bean;

public class Bean3Factory {

	//普通的方法，返回Bean3对象
	public Bean3 getBean3() {
		return new Bean3();
	}
}
