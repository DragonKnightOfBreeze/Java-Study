# Mybatis 通用 Mapper 基础方法实现

[![Maven central](https://maven-badges.herokuapp.com/maven-central/tk.mybatis/mapper-base/badge.svg)](https://maven-badges.herokuapp.com/maven-central/tk.mybatis/mapper-base)

