package tk.mybatis.mapper.version;

import tk.mybatis.mapper.common.Mapper;

/**
 * @author liuzh
 */
public interface UserIntMapper extends Mapper<UserInt> {

}
