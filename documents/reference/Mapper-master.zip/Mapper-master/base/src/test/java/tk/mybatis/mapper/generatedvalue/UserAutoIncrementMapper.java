package tk.mybatis.mapper.generatedvalue;

import tk.mybatis.mapper.common.Mapper;

/**
 * @author liuzh
 */
public interface UserAutoIncrementMapper extends Mapper<UserAutoIncrement> {

}
