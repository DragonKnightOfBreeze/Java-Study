package tk.mybatis.mapper.keysql;

import tk.mybatis.mapper.common.Mapper;

/**
 * @author liuzh
 */
public interface UserAutoIncrementIdentityMapper extends Mapper<UserAutoIncrementIdentity> {

}
