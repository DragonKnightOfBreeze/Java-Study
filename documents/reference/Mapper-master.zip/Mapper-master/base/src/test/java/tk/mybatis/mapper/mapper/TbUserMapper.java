package tk.mybatis.mapper.mapper;

import tk.mybatis.mapper.common.Mapper;
import tk.mybatis.mapper.model.TbUser;

public interface TbUserMapper extends Mapper<TbUser> {

}
