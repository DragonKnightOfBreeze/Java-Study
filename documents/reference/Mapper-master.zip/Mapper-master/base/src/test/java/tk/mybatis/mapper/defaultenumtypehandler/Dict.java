package tk.mybatis.mapper.defaultenumtypehandler;

/**
 * @author liuzh
 */
public interface Dict {

    int getValue();

    String getName();

}
