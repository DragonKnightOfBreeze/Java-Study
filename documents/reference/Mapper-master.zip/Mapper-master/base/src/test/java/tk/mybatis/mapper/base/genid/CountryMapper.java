package tk.mybatis.mapper.base.genid;

import tk.mybatis.mapper.common.base.BaseInsertMapper;

public interface CountryMapper extends BaseInsertMapper<Country> {

}
