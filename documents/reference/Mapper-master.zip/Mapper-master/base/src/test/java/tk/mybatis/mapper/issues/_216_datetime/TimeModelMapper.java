package tk.mybatis.mapper.issues._216_datetime;

import tk.mybatis.mapper.common.Mapper;

/**
 * @author liuzh
 */
public interface TimeModelMapper extends Mapper<TimeModel> {

}
