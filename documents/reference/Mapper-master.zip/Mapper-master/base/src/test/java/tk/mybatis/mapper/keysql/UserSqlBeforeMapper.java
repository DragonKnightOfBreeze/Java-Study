package tk.mybatis.mapper.keysql;

import tk.mybatis.mapper.common.Mapper;

/**
 * @author liuzh
 */
public interface UserSqlBeforeMapper extends Mapper<UserSqlBefore> {

}
