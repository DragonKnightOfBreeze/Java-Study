package tk.mybatis.mapper.base;

import tk.mybatis.mapper.common.Mapper;

public interface CountryMapper extends Mapper<Country> {

}
