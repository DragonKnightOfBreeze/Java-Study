package tk.mybatis.mapper.generatedvalue;

import tk.mybatis.mapper.common.Mapper;

/**
 * @author liuzh
 */
public interface UserAutoIncrementIdentityMapper extends Mapper<UserAutoIncrementIdentity> {

}
