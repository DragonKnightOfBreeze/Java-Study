package tk.mybatis.mapper.issues._216_datetime;

import tk.mybatis.mapper.common.Mapper;

/**
 * @author liuzh
 */
public interface TimeModel2Mapper extends Mapper<TimeModel2> {

}
