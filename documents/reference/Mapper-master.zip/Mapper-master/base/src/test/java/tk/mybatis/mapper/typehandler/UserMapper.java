package tk.mybatis.mapper.typehandler;

import tk.mybatis.mapper.common.Mapper;

/**
 * @author liuzh
 */
public interface UserMapper extends Mapper<User> {

}
