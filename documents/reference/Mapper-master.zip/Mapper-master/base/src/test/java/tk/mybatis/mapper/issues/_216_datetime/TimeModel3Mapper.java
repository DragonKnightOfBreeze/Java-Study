package tk.mybatis.mapper.issues._216_datetime;

import tk.mybatis.mapper.common.Mapper;

/**
 * @author liuzh
 */
public interface TimeModel3Mapper extends Mapper<TimeModel3> {

}
