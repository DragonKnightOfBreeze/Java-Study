package tk.mybatis.mapper.typehandler;

/**
 * @author liuzh
 */
public enum StateEnum {
    disabled,
    enabled,
}
