package tk.mybatis.mapper.additional.dialect.oracle;

import tk.mybatis.mapper.common.base.BaseSelectMapper;

/**
 * @description:
 * @author: qrqhuangcy
 * @date: 2018-11-17
 **/
public interface DemoCountryMapper extends BaseSelectMapper<DemoCountry>, OracleMapper<DemoCountry> {
}
