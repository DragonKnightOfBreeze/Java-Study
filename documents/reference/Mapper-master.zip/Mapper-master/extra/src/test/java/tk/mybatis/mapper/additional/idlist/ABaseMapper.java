package tk.mybatis.mapper.additional.idlist;

/**
 * @author liuzh
 */
public interface ABaseMapper<T> extends IdListMapper<T, Long> {

}
