package tk.mybatis.mapper.additional.insertlist;

import tk.mybatis.mapper.additional.insert.InsertListMapper;

public interface UserMapper extends InsertListMapper<User> {

}
