package tk.mybatis.mapper.additional;


import tk.mybatis.mapper.additional.idlist.IdListMapper;

public interface CountryMapper extends IdListMapper<Country, Long> {

}
