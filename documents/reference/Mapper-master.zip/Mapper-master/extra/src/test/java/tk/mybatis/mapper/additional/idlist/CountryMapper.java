package tk.mybatis.mapper.additional.idlist;


import tk.mybatis.mapper.additional.Country;

public interface CountryMapper extends ABaseMapper<Country> {

}
