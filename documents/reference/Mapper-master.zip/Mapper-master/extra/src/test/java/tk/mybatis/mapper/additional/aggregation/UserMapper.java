package tk.mybatis.mapper.additional.aggregation;

public interface UserMapper extends AggregationMapper<User> {

}
