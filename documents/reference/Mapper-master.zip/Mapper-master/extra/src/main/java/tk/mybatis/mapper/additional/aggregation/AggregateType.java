package tk.mybatis.mapper.additional.aggregation;

/**
 * 聚合查询函数
 *
 * @author liuchan
 */
public enum AggregateType {

    AVG, SUM, COUNT, MAX, MIN
}
