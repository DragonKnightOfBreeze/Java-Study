package tk.mybatis.mapper.additional.dialect.oracle;

/**
 * @description: Oracle独有方法
 * @author: qrqhuangcy
 * @date: 2018-11-15
 **/
@tk.mybatis.mapper.annotation.RegisterMapper
public interface OracleMapper<T> extends InsertListMapper<T> {
}
