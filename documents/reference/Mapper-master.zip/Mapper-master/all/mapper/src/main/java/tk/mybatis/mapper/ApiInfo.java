package tk.mybatis.mapper;

/**
 * Java Doc 内容请通过各个独立项目进行查看
 *
 * @author liuzh
 */
public class ApiInfo {
}
