# Mybatis 通用 Mapper3 适配

为了帮助用户从通用 Mapper 3.x 过渡到 4.x 和以后的版本，增加本项目。

本项目下面提供了两个子模块，基于 Maven 依赖传递的 **dependencies** 和基于 maven-shade-plugin 打包为一个大 jar 包的 **mapper** 项目。

**并且本项目下面的 jar 的 Maven 为 tk.mybtis:mapper，也就是从 mapper 3.x 升级到 4.x 的时候可以只改版本号。**

